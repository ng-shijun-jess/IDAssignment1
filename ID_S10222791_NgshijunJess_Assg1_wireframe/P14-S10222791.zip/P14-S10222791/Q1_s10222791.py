#Ng shijun jess S10222791-P14
d = float(input('Enter the dewpoint temperature in Celcius: '))
pressure = 6.11 * 10 ** ((7.5 * d) / (237.3 + d))

print(' the vapour pressure is {:.2f} millbars '.format(pressure))

