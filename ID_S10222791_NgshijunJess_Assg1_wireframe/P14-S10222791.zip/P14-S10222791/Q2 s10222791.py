#Ng shijun jess S10222791-P14
name_list = input('Enter 3 names seperated with comma: ')
name_list = name_list.split(',')




if len(name_list[2]) >= len(name_list[1]) and len(name_list[2]) >= len(name_list[0]):
    print('{} is the longest name'.format(name_list[2]))
else:
    print('{} is not the longest name'.format(name_list[2]))
