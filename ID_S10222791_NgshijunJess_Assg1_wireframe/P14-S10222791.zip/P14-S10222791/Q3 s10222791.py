#Ng shijun jess S10222791-P14
GTIN = '87654313'
student_GTIN = input('Enter GTIN: ')

step_1 = int(student_GTIN[0]) * int(GTIN[0]) + int(student_GTIN[2]) * int(GTIN[2]) + int(student_GTIN[4]) * int(GTIN[4]) + int(student_GTIN[6]) * int(GTIN[6])
step_2 = int(student_GTIN[1]) * int(GTIN[1]) + int(student_GTIN[3]) * int(GTIN[3]) + int(student_GTIN[5]) * int(GTIN[5])
step_3 = int(student_GTIN[7]) * int(GTIN[7])

total = step_1 + step_2 + step_3
total_str = str(total)
last_index = total_str[1]

if student_GTIN[8] == last_index:
    print('the GTIN {} is valid'.format(student_GTIN))
else:
    print('the GTIN {} is invalid'.format(student_GTIN))
        
